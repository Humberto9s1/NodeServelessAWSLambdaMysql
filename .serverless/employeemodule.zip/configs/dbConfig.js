const mysql = require('mysql')
const connection  = mysql.createPool({
    host: "employeemodule.cx9jcjnv1yee.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "Rmv1231gtA5",
    database: "module_employee"
})

module.exports = connection